import { Link } from 'react-router-dom';
import { useAuth } from '../authContext.jsx';
import { get } from '../api.js';
import { useLoad } from '../hooks.js';
import { BookCard } from '../components/ui.jsx';

const FEATURES = [
  ['📚', 'Share your shelf', 'List the physical books you own. Neighbours in your building, hostel or street can find them.'],
  ['📷', 'Photo-checked lending', 'A few photos at pickup and return mean no “it was like that when I got it”.'],
  ['🌿', 'Trust you can see', 'Star ratings and an on-time return record, side by side, with the real counts.'],
  ['🕯️', 'Clubs & reading rooms', 'Chat with readers nearby, join a book club, or read together in a cosy live room.']
];

export default function Home() {
  const { user } = useAuth();
  const recs = useLoad(() => (user ? get('/recommendations') : Promise.resolve([])), [user?.id]);
  const fresh = useLoad(() => (user ? get('/books', { scope: 'parent' }) : Promise.resolve([])), [user?.id]);

  return (
    <>
      <section className="hero">
        <div className="stack">
          <span className="hand">Pull up a chair…</span>
          <h1>Walk into a library that grows between your neighbours’ shelves.</h1>
          <p className="muted" style={{ fontSize: '1.1rem' }}>
            BookShare turns the books gathering dust in one building, hostel or neighbourhood into a single, searchable community library,
            tracked from request to return so every book finds its way home.
          </p>
          <div className="row">
            {user ? <><Link className="btn" to="/library">Browse the library</Link><Link className="btn honey" to="/books/new">Shelve a book</Link></>
              : <><Link className="btn" to="/register">Join the library</Link><Link className="btn ghost" to="/login">I already have a card</Link></>}
          </div>
        </div>
        <div className="arch" aria-hidden="true">
          <div className="arch-inner">
            <div className="lantern" />
            <div style={{ fontSize: '3rem' }}>🕯️📖🌲</div>
            <h2 style={{ marginBottom: 0 }}>Lend. Borrow.<br />Return.</h2>
            <span className="hand">“a story waits on every shelf”</span>
          </div>
        </div>
      </section>

      <section className="grid" style={{ marginTop: '1.5rem' }}>
        {FEATURES.map(([ico, t, d]) => (
          <div key={t} className="card feature stitched"><div className="ico">{ico}</div><h3>{t}</h3><p className="muted small">{d}</p></div>
        ))}
      </section>

      {user && recs.data?.length > 0 && (
        <>
          <div className="section-title"><h2>Readers like you also borrowed</h2><span className="hand">picked from real borrowing history</span></div>
          <div className="grid">{recs.data.map((b) => <BookCard key={b.id} book={b} />)}</div>
        </>
      )}
      {user && fresh.data?.length > 0 && (
        <>
          <div className="section-title"><h2>Newly shelved nearby</h2><span className="hand">fresh from the neighbourhood</span></div>
          <div className="grid">{fresh.data.slice(0, 8).map((b) => <BookCard key={b.id} book={b} />)}</div>
        </>
      )}
    </>
  );
}
